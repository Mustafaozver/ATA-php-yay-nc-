
			<div class="welcome-box">
				<div class="container">
					<h1>Hata <span>404</span></h1>
					<?php
echo $_SERVER["REQUEST_URI"]." Sayfası bulunamadı";
?><br />
					<b style="color:gray">Ana sayfaya gimek için <a href="/">tıklayın</a>.</b>
				</div>
			</div>