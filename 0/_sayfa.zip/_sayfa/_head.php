  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1254" />
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" />
  <meta http-equiv="Content-Type" content="text/html; charset=x-mac-turkish" />
  <meta name="generator" content="ATA 1.0" />
  <link rel="canonical" href="http://<?php echo $ata["Domain"]; ?>/" />  
  
  
  
  
   <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,700,600,300' rel='stylesheet' type='text/css'>
   <link rel="stylesheet" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/bootstrap.css" type="text/css" media="screen">
   <link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/fullwidth.css" media="screen" />
   <link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/settings.css" media="screen" />
   	<link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/magnific-popup.css" media="screen">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/owl.carousel.css" media="screen">
    <link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/owl.theme.css" media="screen">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/jquery.bxslider.css" media="screen">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/style.css" media="screen">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $ata["Domain"]; ?>/dosyalar/css/responsive.css" media="screen">


	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/jquery.min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/jquery.migrate.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/jquery.magnific-popup.min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/bootstrap.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/raphael-min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/DevSolutionSkill.min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/retina-1.1.0.min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/jquery.bxslider.min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/plugins-scroll.js"></script>

     <!-- jQuery KenBurn Slider  -->
    <script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/jquery.themepunch.revolution.min.js"></script>
	<script type="text/javascript" src="http://<?php echo $ata["Domain"]; ?>/dosyalar/js/script.js"></script>
	
  <meta property="og:title" content="<?php echo $icerik["baslik"]; ?>" />
  <meta property="og:type" content="blog" />
  
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link title="Rss" href="/tr-tr/_layouts/15/Magiclick.Aselsan.Website/feed.aspx" rel="alternate" type="application/rss+xml">
  <link rel="shortcut icon" href="http://www.aspilsan.com.tr/wp-content/uploads/2016/02/logo-2.png" />
  <link rel="profile" href="http://gmpg.org/xfn/11" />
  <link rel="pingback" href="http://www.aspilsan.com.tr/xmlrpc.php" />
  

  <meta property="og:url" content="http://<?php echo $ata["Domain"].$_SERVER["REQUEST_URI"]; ?>" />
  <meta property="og:image" content="<?php echo $icerik["resim"]; ?>" />
  <meta property="og:site_name" content="<?php echo $ata["Domain"]; ?>" />
  <meta property="og:description" content="<?php echo $icerik["tanim"]; ?>" />
  <meta name="twitter:card" content="summary" />
  <meta name="twitter:title" content="<?php echo $icerik["baslik"]; ?>" />
  <meta name="twitter:description" content="<?php echo $icerik["tanim"]; ?>" />
  <meta name="twitter:image" content="<?php echo $icerik["resim"]; ?>" />
  <meta itemprop="image" content="<?php echo $icerik["resim"]; ?>" />
  <meta name="title" content="<?php echo $icerik["baslik"]; ?>" />
  <meta name="description" content="<?php echo $icerik["tanim"]; ?>" />
  <meta name="keywords" content="<?php echo $icerik["anahtarlar"]; ?>" />
  <meta name="author" content="<?php echo $icerik["yazar"]; ?>" />
  <meta name="owner" content="<?php echo $ata["Domain"]; ?>" />
  <meta name="copyright" content="(c) 2015" />
  <title><?php echo $icerik["baslik"]." - ".$ata["Domain"]; ?></title>
