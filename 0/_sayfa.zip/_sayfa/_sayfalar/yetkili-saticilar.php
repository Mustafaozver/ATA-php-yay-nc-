﻿<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">BELGE ELEKTRONİK SAN. VE TİC.<br />
LTD.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ŞARAMPOL CAD. 468 SOK. KAYNAK AP. NO:6/8 ANTALYA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0242 242 76 51</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0242 242 20 40</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-left: none; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">CEYMAK MAKİNA MEHMET DEMİR</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">İ.O.S.B 1387 SOKAK NO:4</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0312 395 73 66</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0312 394 31 99</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-left: none; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">REGÜLE ELEKROMARKET LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">KIZILAY CAD. KIZILAY İŞHANI KAT:2 NO:6 ADANA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0322 359 53 75</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0322 359 53 74</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 1;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">İLETİŞİM ELEKTRONİK</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ŞAİR FUZULİ CAD. BAYKAN APT. NO:10 K:5 D:9/10 ESKİŞEHİR</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0222 230 53 77</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0222 230 66 64</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">MEBA ELEKTRONİK LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">M. AKSOY BULVARI PRESTİJ İŞ MRKZ. 9 NOLU GEÇ. NO:9 KAT:2 GAZİANTEP</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0342 215 00 85</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0342 215 00 05</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ACS TEKNOLOJİ SİSTEMLERİ İML. <span class="GramE">İNŞ.TAAH</span>.TİC.LTD.ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ÇETİN EMEÇ BULV.1065.CAD NO:34/9 ANKARA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0312 472 62 76</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0312 472 62 78</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 2;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ASKOM LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">KARAMAN MAH.NERGİZ CAD. NO:4/A AFYON</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0272 213 46 56</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0272 213 73 80</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">FAEM ELEKTRONİK</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">1428 SOKAK NO:9 DAİRE:2 İZMİR</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0232 463 38 76</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0232 463 57 49</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ONUR ELEKTRONİK LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ZEYBEK MAH. SANAYİ ALT CAD. NO:1 AYDIN</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0256 212 18 16</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0256 214 52 11</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 3;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ÇABANET HABERLEŞME CİHAZLARI<br />
BAKIM ONARIM SATIŞ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ALTI EYLÜL MAH/SEMT 4 ÇİĞDEM SK. 9/1 ALTIEYLÜL BALIKESİR</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0266 244 53 17</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0266 241 27 81</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">IRMAK LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">KIZILSARAY MAH. MİLLİ EGEMENLİK CAD. 86.SOK. NO:38/1 ANTALYA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0242 244 59 49</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0242 244 59 48</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">DELTA TELEKOM <span class="GramE">SAN.TİC.</span> LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">PİRİREİS MAH. İSMET İNÖNÜ BULV.1106.SOK. NO:1 ESK. APT. KAT:2 DAİRE:3<br />
MERSİN</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0324 326 46 46</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0324 326 56 56</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 4;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ER ELEKTRİK SAN. VE TİC. LTD.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">M.KEMAL MAH. H.OKAN MERZECİ BULV. NO:396/A MERSİN</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0324 226 36 37</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0324 226 36 36</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">BATI KARADENİZ ELEKTRONİK TİC.<br />
LTD. ŞTİ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">TOPLU İŞ MERKEZİ B BLOK NO:4 KASTAMONU</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0366 215 13 03</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0366 215 11 88</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">TUNÇ OTO UFUK TUNÇ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">SANTRAL</b> GARAJ MAH.<br />
ULUBATLI HASAN BULVARI NO:22/B BURSA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0224 251 42 42</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0224 272 67 67</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 5;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ASTEL ELEKTRONİK HAB. VE<br />
GÜVENLİK SİSTEMLERİ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">HALK CAD. NO:93/A DENİZLİ</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0258 263 27 23</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0258 241 53 54</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">SOMAY TELEKOMÜNİKASYON TİC.<br />
LTD. ŞTİ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">TOKLU MAH. Y.SELİM BULV. 7.SOK. NO:12 K:1 TRABZON</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0462 229 33 70</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0462 229 98 31</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ALTINSOY LTD. ŞTİ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">REŞATBEY MH. 62028 SOKAK ABDURRAHİM GİZER APT. B <span class="GramE">BL.NO</span>:4/A<br />
ZEMİN KAT ADANA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0322 457 85 55</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0322 454 08 42</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 6;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">YÜCEL MARKONİ HABERLEŞME<br />
LTD.ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">1428 SOKAK NO:1/1 İZMİR</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0232 464 01 06</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0232 464 01 06</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">BEM BERK ELEKTRİK VE<br />
MÜHENDİSLİK SAN. <span class="GramE">ve</span> TİC. LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">STRAZBURK CAD. NO:40/A ANKARA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0312 230 25 25</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0312 230 34 97</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">FARK TELEKOMÜNİKASYON İNŞAAT<br />
ELEKTRİK <span class="GramE">SAN.TİC.LTD</span>.ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ALİEMİRİ 7. SOK. GENÇYILMAZ APT. ALTI NO:23/A DİYARBAKIR</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0412 224 29 61</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0412 228 51 75</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 7;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">BİLCOMİN SAN. VE TİC.<br />
PAZARLAMA LTD.ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">K.SOKU MAH.ABİDİNPAŞA CAD. 28006 SOK. AKYÜZ İŞHANI KAT 5 NO:601 ADANA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0322 352 96 03</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0322 352 81 04</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">DOĞU-TECH</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">İSTASYON MAH. GALERİCİLER SİTESİ K:2 NO:414/415 ERZURUM</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0442 242 23 23</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0442 242 02 00</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">TONSES ELEKTRONİK <span class="GramE">SAN.VE</span> TİC. LTD.ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">MANSUROĞLU MAH. ANKARA CAD.NO:113/1 1 NOLU <span class="GramE">DÜKKAN</span><br />
İZMİR</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0232 445 03 33</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0232 445 40 57</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 8;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ASTELSAN İLETİŞİM TİC. LTD.<br />
ŞTİ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">RAUF DENKTAŞ CAD. HUZUR SİTESİ ALTI NO:14/B KONYA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0332 237 33 66</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0332 237 33 77</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">SELÇUK MÜESSESESİ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">SERDAR CADDESİ NO:17/C KAYSERİ</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0352 231 13 42</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0352 231 13 42</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">AYBERK ÇETİNKAYA</b> <span class="GramE">İNŞ.ELEKTRİK</span>.SAN.TİC.LTD.ŞTİ.</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">FEVZİ ÇAKMAK MAH. BOZANTI CAD. NO:124/1 KAYSERİ</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0352 338 01 35</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 9;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">PEGASUS SAVUNMA SAN. VE TİC.<br />
LTD. ŞTİ</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">TEPEPRİME İŞ MERKEZİ MUSTAFA KEMAL MAH. DUMLUPINAR BULVARI NO:266 A<br />
BLOK NO:32 ANKARA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0312 447 56 14</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0312 446 68 44</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">REKOR BİLİŞİM LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ŞERAFETTİN CAD.GÖRÜCÜ SOKAK NO:10/A KONYA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0332 350 90 19</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0332 350 55 49</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">KÖRFEZ HABERLEŞME VE GÜV. SİS.<br />
<span class="GramE">SAN.TİC.</span></b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ÖMERAĞA MAH. ŞAHABETTİN BİLGİSU CAD.NO:38 D.3 İZMİT</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0262 324 68 38</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0262 322 41 69</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 10;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">SAYKOM ELEKTRONİK HAB. GÜV.<br />
SİST. LTD.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">CUMHURİYET CAD. PAŞABAĞI MAH. ADLİYE İŞ MERKEZİ NO:5 ŞANLIURFA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0414 315 37 04</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0414 316 19 30</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ARMET İLETİŞİM</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">KIRÇUVAL MAH.CEZMİ KARTAY CAD. 2 NEBİOĞLU SOKAK 25/A MALATYA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0422 325 72 00</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0442 323 54 84</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">ASMAR ELEKRONİK LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">UNCUBOZKÖY MAH. 5501 SOKAK NO:9/A MANİSA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0236 237 94 00</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0236 237 71 17</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 11;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">EKVATOR İLETİŞİM<br />
TELEKOMÜNİKASYON</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">KARŞIYAKA MAH. ATATÜRK BULV. NO:492/A ORDU</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0452 233 35 85</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0452 233 35 25</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">UZMAN ELEKTRONİK <span class="GramE">SAN.TİC.LTD</span>.ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">PİRİÇELEBİ MAH. ZİHNİDERİN CAD. NO:25/A RİZE</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0464 213 16 87</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0464 214 67 17</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">BİRİKİM PİLLERİ BATARYA <span class="GramE">SAN.TİC.</span> LTD.ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">PERPA TİC. MERKEZİ A BLOK KAT:2 NO:22 İSTANBUL</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0212 251 15 85</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0212 251 94 33</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 12;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">TEKNOSEL ELEKTRONİK GÜVENLİK</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">SAHAB. MAH. METE CAD. OTAK SOK. KAMER APT.NO:2 KAYSERİ</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0352 222 45 97</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ANKA<b style="mso-bidi-font-weight: normal;">TEL HABERLEŞME LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">YILDIZEVLER MAH. RABİNDRANATH TAGORE CAD. ERGENEKON İŞ MERK. NO:27/2<br />
YILDIZ ANKARA</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0312 442 81 00</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0312 442 81 02</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">DOĞUŞ ELEKTRONİK</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">ESKİ CAMİ MH. KOLORDU CAD.NO:61 TEKİRDAĞ</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0282 263 42 77</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<br />
<tr style="mso-yfti-irow: 13; mso-yfti-lastrow: yes;">
<td style="width: 184.3pt; border: solid #D9D9D9 1.0pt; mso-border-themecolor: background1; mso-border-themeshade: 217; border-top: none; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><b style="mso-bidi-font-weight: normal;">DELTA TELEKOM <span class="GramE">SAN.TİC.</span> LTD. ŞTİ.</b></p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">PİRİREİS MAH. İSMET İNÖNÜ BULV.1106.SOK. NO:1 ESK. APT. KAT:2 DAİRE:3<br />
MERSİN</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">Tel: 0324 326 46 46</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;"><span class="SpellE">Fax</span>: 0324 326 56 56</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 184.25pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="246">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">

<td style="width: 179.35pt; border-top: none; border-left: none; border-bottom: solid #D9D9D9 1.0pt; mso-border-bottom-themecolor: background1; mso-border-bottom-themeshade: 217; border-right: solid #D9D9D9 1.0pt; mso-border-right-themecolor: background1; mso-border-right-themeshade: 217; mso-border-top-alt: solid #D9D9D9 .5pt; mso-border-top-themecolor: background1; mso-border-top-themeshade: 217; mso-border-left-alt: solid #D9D9D9 .5pt; mso-border-left-themecolor: background1; mso-border-left-themeshade: 217; mso-border-alt: solid #D9D9D9 .5pt; mso-border-themecolor: background1; mso-border-themeshade: 217; padding: 0cm 5.4pt 0cm 5.4pt;" valign="top" width="239">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">