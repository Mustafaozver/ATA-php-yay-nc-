﻿<p>Ürünlerimizin kalitesi aşağıda belirtilen dünya standardları ve askeri şartname kalite isteklerini çok fazlasıyla karşılamaktadır.</p>
<ul>
<li>IEC Standardları,</li>
<li>Alman (VG95238T2) ve</li>
<li>Amerikan (MIL-B-26220C &amp; D) Askeri şartnameleri,</li>
<li>BWB (Alman) ve SOPEMA (Fransız) sertifikaları</li>
</ul>
<p>Özellikle, 1990&#8217;dan beri üretimi devam eden uçak ve helikopter akülerinin kalite ve performansı IEC 952-1 standardı ve Amerikan askeri şartnamesi MIL-B-26220D ile Alman askeri şartnamesi VG95238T kalite isteklerinin çok üstündedir. Bundan dolayı 7 ile 40 Ah arasındaki uçak akülerimiz bugün birçok askeri uçak ve helikopterde güvenle kullanılmaktadır.</p>
<p>ASPİLSAN AQAP-2120 Endüstriyel Kalite Güvence Seviyesi Belgesine sahiptir. Ayrıca; ASPİLSAN ISO 9001:2008 Kalite Yönetim Sistem Belgesine sahiptir.</p>